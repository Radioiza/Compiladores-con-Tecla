



import java.util.ArrayList;

public interface Funcion {

    public abstract void ejecutar(Object A, ArrayList parametros);
    
}
